package MockFinal;

import org.junit.Test;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestClass {

    @Test
    public void testing(){
          UrlClass urlConcrete = new UrlClass();
          UrlClass url = mock(UrlClass.class);
         // Mockito.when(url.concatString("r","v")).thenReturn("Vishwa ratna");
        given(url.concatString("v","r")).willReturn("Vishwa Ratna");
          assertEquals("Vishwa Ratna",url.concatString("v","r"));
    }

}
