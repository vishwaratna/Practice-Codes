package MockFinal;

import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;


final class UrlClass {
    public String concatString(String s1, String s2){
         return s1.concat(s2);
    }
 }
