package OverlappingRectangle;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        List<Rectangle> rectangleList = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        String [] stringArray ;
        int no_OfTestcases = sc.nextInt();
        sc.nextLine();
        for(int i=0;i<no_OfTestcases;i++){
            stringArray = sc.nextLine().split(" ");
            rectangleList.add(new Rectangle(new Point(Integer.parseInt(stringArray[0]),Integer.parseInt(stringArray[1])),new Point(Integer.parseInt(stringArray[2]),Integer.parseInt(stringArray[3]))));
        }
        boolean sayOverlappingOrnot = isOverlapping(rectangleList.get(0),rectangleList.get(1));
        System.out.println(sayOverlappingOrnot);
    }
   static boolean isOverlapping(Rectangle a , Rectangle b){
        if(a.getTopRight().getX()<b.getBottonLeft().getX()||b.getTopRight().getX()<a.getBottonLeft().getX()){
            return false;
        }
        if(a.getTopRight().getY()<b.getBottonLeft().getY()||b.getTopRight().getY()<a.getBottonLeft().getY()){
            return false;
        }
        return true;
    }
}
