package OverlappingRectangle;

public class Rectangle {
    private Point bottonLeft;
    private Point topRight;

    public Point getBottonLeft() {
        return bottonLeft;
    }

    public void setBottonLeft(Point bottonLeft) {
        this.bottonLeft = bottonLeft;
    }

    public Point getTopRight() {
        return topRight;
    }

    public void setTopRight(Point topRight) {
        this.topRight = topRight;
    }

    public Rectangle(Point bottonLeft, Point topRight) {
        this.bottonLeft = bottonLeft;
        this.topRight = topRight;
    }
}
