package TakeMultipleInput;

import java.io.IOException;


public class Race {
   static class FIRST{
        void one(){
            System.out.println("This is base class");
        }
    }
  static  class  SECOND extends FIRST{
       void two(){
           System.out.println("This inherits class FIRST");
        }
    }
    static  class  THIRD extends SECOND{
        void three(){
            System.out.println("This inherits class SECOND");
        }
    }
    public static void main(String[] args) throws IOException {

        THIRD t = new THIRD();
        t.one();
        t.two();
        t.three();

        }
    }

