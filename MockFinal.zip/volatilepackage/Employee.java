package volatilepackage;

public class Employee {
    Integer pinCode;

    public Employee(Integer pinCode) {
        this.pinCode = pinCode;
    }

    public Integer getPinCode() {
        return pinCode;
    }

    public void setPinCode(Integer pinCode) {
        this.pinCode = pinCode;
    }
}
