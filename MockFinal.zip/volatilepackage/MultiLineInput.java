package volatilepackage;


import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


public class MultiLineInput {
    static int l = 0;
    static int m = 0;

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        int numberOfLinesToRead = 2;//  s.nextInt();
        int[] array = new int[numberOfLinesToRead];
        for (int i = 0; i < array.length; i++) {
            array[i] = s.nextInt();
        }
        List<Integer> list = IntStream.rangeClosed(array[0], array[1]).boxed().collect(Collectors.toList());
        IntStream.rangeClosed(array[0], array[1]).boxed().forEach(k -> {

            if (BigInteger.valueOf(list.get(m)).isProbablePrime(1) == true) {
                System.out.println("prime " + list.get(m));
                l++;

            }
            m++;

        });
        System.out.println(l);

    }
}

//.map(k -> {
//        if (BigInteger.valueOf(list.get(k)).isProbablePrime(1) == true) {
//        k++;
//        return l++;
//        }
//        k++;
//        return false;
//        }).count();