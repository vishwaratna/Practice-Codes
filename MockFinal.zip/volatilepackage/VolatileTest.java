//package volatilepackage;
//
//import java.util.HashMap;
//import java.util.Map;
//
//public class VolatileTest {
//    public static void main(String[] args) {
//       Map<Employee, String> empMap = new HashMap<>();
//        empMap.put(new Employee(127), "James");
//        empMap.put(new Employee(128), "Jake");
//        empMap.put(new Employee(129), "Johnson");
//        empMap.put(new Employee(130), "Logan");
//        empMap.put(new Employee(131), "KSI");
//        empMap.put(new Employee(132), "Johnson");
//
//      //  empMap.entrySet().stream().map(Map.Entry::getValue).filter(s->String.e)
//    }
//}
